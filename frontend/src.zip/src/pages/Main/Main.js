import React from 'react';

import Header from '../../components/Header/Header';

const Main = () => {
    return (
        <>
            <Header />
            <h1>Главная страница</h1>
        </>
    );
};

export default Main;