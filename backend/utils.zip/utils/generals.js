import path from "path"

export const DIRNAME = path.join(import.meta.url, "../../../").slice(6)